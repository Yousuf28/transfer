

library(shiny)


ui <- fluidPage(
   
   # Application title
   titlePanel("BayesianTox"),
   
   
   fluidRow(
     column(width = 3,
       numericInput('ESSc', label = 'Effective Sample Size for Control (ESSc)',
                    min = 0, value = 10)
     ),
     
     column(width = 3,
            numericInput('HCrate', label = 'Historical Control Incidence Rate',
                         min = 0, max = 1,step = 0.01, value = 0.25)),
     column(width = 3,
            numericInput('ESSt', label = 'Effective Sample Size for Treatment (ESSt)',
                         min = 0, value = 1))),
   
   
   
   fluidRow(
     column(width = 3,
            numericInput('Cgroup', label = 'Control Group Size',
                         min = 0, value = 3)),
     column(width = 3,
            uiOutput("Cincident")),
     
     
     # column(width = 3,
     #        numericInput('Cincident', label = 'Incidence in Control Group',
     #                     min = 0, value = 1)),
     column(width = 3,
            numericInput('Tgroup', label = 'Treatment Group Size',
                         min = 0, value = 3)),
     column(width = 3,
            uiOutput('Tincident'))
     
     
   ),
   actionButton('submit', "Update"),
   
   shiny::tableOutput('post_table')
   
)

# Define server logic required to draw a histogram
server <- function(input, output) {
   
  
   
  
  
  
  output$Cincident <- renderUI({
    sliderInput('control_group_incident', label = 'Incidence in Control Group',
                min = 0, max = input$Cgroup, value = 1, step = 1)
  })
  
  output$Tincident <- renderUI({
    sliderInput('treatment_group_incident', label = 'Incidence in Treatment Group',
                min = 0, max = input$Tgroup, value = 2, step = 1)
  })
  
  
  post_prob <- reactive({
    
    if (!is.null(input$control_group_incident)) {
      
    df <- data.frame(matrix(ncol = 7))
    col_names <- c('Control Mean', 'Treatment Mean','Post Mean Diff',
                   'Confidence Interval (0.025)','Confidence Interval (0.975)','Success', 'Probability')
    colnames(df) <- col_names
    
    control_alpha_prior <- input$ESSc * input$HCrate
    control_prior_beta <- input$ESSc - control_alpha_prior
    trt_prior_alpha <- input$ESSt * input$HCrate
    trt_prior_beta <- input$ESSt - trt_prior_alpha
    
    # simulation
    set.seed(1234)
    N <- 100000
    control_post_samples <- rbeta(n=N, shape1 = control_alpha_prior+input$control_group_incident,
                                  shape2 = control_prior_beta+ input$Cgroup - input$control_group_incident)
    
    trt_post_samples <- rbeta(n=N,
                              shape1 = trt_prior_alpha+ input$treatment_group_incident,
                              shape2 = trt_prior_beta+ input$Tgroup - input$treatment_group_incident)
    control_mean <- mean(control_post_samples)
    trt_mean <- mean(trt_post_samples)
    post_mean_diff <- trt_mean - control_mean
    post_quant <- quantile(trt_post_samples - control_post_samples, probs = c(0.025,0.975))
    success <- post_quant[1] > 0
    post_probability <- sum(trt_post_samples - control_post_samples > 0)/N
    df[1,'Control Mean'] <- control_mean
    df[1,'Treatment Mean'] <- trt_mean
    df[1, 'Post Mean Diff'] <- post_mean_diff
    df[1, 'Confidence Interval (0.025)'] <- post_quant[1]
    df[1, 'Confidence Interval (0.975)'] <- post_quant[2]
    df[1,'Success'] <- success
    df[1,'Probability'] <- post_probability
    df
  }
    
  })
  
  output$post_table <- shiny::renderTable({
    #req(input$submit)
    #input$submit
    post <- post_prob()
    post
  })
  
  
  
}

# Run the application 
shinyApp(ui = ui, server = server)

