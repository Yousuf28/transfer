rm(list=ls())

library(tidyverse)

PostProb <- NULL
Success <- NULL
nAnimals <- 10 #!!!!!!!!!!!!!!!!!!!
Rate <- seq(0,nAnimals,by=1)
for (rate in Rate) {
  HCrate <- 0.267 #!!!!!!!!!!! Historical control event rate
  #OCrate <- rate
  OTrate <- 0.25
  
  #### Basic Simulations ####
  n <- nAnimals # Number of animals per sex per group
  N <- 100 # Number of simulations to run
  Nbeta <- 10000 # sample size of beta distribution
  #control <- rbinom(n = N, size = n, prob = OCrate)
  #treatment <- rbinom(n = N, size = n, prob = OTrate)
  control <- 5 #!!!!!!!!!!
  treatment <- rate
  
  # Question: How does ESS relate to n?
  # Question: How do we choose ESSc vs. ESSt (would a ratio make sense?)
  
  ESSc <- n #!!!!!!!!! Effective Sample Size for control
  ESSt <- n*.1 #!!!!!!!!!!!! Effective Sample Size for treatment
  ctrlprioralpha  <-  HCrate * ESSc
  ctrlpriorbeta <- ESSc - ctrlprioralpha
  trtprioralpha <- HCrate * ESSt
  trtpriorbeta <- ESSt - trtprioralpha
  
  output <- c()
  for (i in 1:length(control)){
    ctrlpostsamples <- rbeta(n = Nbeta, shape1 = ctrlprioralpha + control[i], shape2 = ctrlpriorbeta + n - control[i])
    trtpostsamples <- rbeta(n = Nbeta, shape1 = trtprioralpha + treatment[i], shape2 = trtpriorbeta + n - treatment[i])
    ctrlmean <- mean(ctrlpostsamples)
    trtmean <- mean(trtpostsamples)
    postprob <- sum(trtpostsamples - ctrlpostsamples > 0)/Nbeta
    postmeandiff <- mean(trtpostsamples - ctrlpostsamples)
    postquant <- quantile(trtpostsamples - ctrlpostsamples, probs = c(0.025, 0.975))
    success <- postquant[1] > 0
    output <- bind_rows(output, data.frame(ctrlmean = ctrlmean, trtmean = trtmean, postmeandiff = postmeandiff, ci.lb = postquant[1], ci.ub = postquant[2], success = success, postprob = postprob))
  }
  
  Results <- output %>% colMeans()
  # print(Results)
  
  PostProb <- c(PostProb,2*(Results[['postprob']] - 0.5))
  # PostProb <- c(PostProb,(Results[['postprob']]))
  Success <- c(Success,Results[['success']])
}
for (i in seq(length(PostProb))) {
  if (PostProb[i] < 0) {
    PostProb[i] <- 0
  }
}

df <- as.data.frame(cbind(Rate,PostProb,Success))
p1 <- ggplot(df,aes(x=Rate,y=PostProb)) + geom_line() + geom_point() + ylim(c(0,1))
print(p1)

p2 <- ggplot(df,aes(x=Rate,y=Success)) + geom_line() + ylim(c(0,1))
print(p2)


